/* Author: Kelan Riley
   Date: 1/19/2016
   Purpose: Listen for user actions on the first panel that they encounter.
*/
(function() {
    mygrid = new dhtmlXGridObject('gridbox');
    mygrid.setColumnIds("col1,col2,col3");    
    //the path to images required by grid
    /*NOTE: Possible bug in the API for this method because I get an error
      about a file not found when I specify
     */
    mygrid.setImagesPath("../imgs");                 
    mygrid.setHeader("Book title,Author,Price");//the headers of columns  
    mygrid.setInitWidths("250,150,100");          //the widths of columns  
    mygrid.setColAlign("left,left,left");       //the alignment of columns   
    mygrid.setColTypes("ed,ed,ed");                //the types of columns  
    mygrid.setColSorting("str,str,int");          //the sorting types   
    mygrid.init();      //finishes initialization and renders the grid on the page
    data= {"total_count":50000, "pos":0, "data":[
	{ "col1": "A Time to Kill",
	  "col2": "John Grisham",
	  "col3": "100"
	},
	{ "col1": "Blood and Smoke",
	  "col2": "Stephen King",
	  "col3": "1000"
	},
	{ "col1": "The Rainmaker",
	  "col2": "John Grisham",
	  "col3": "-200"
	}
    ]};

    mygrid.parse(data,"js"); //takes the name and format of the data source

})();
