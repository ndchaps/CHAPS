/* Author: Kelan Riley
   Date: 1/19/2016
   Purpose: Just implement some javascript that dynamically changes the
   login page based on incorrect user information. (Assumed incorrect
   because there is no data to test with at the moment).
*/

/* Avoiding pollution of the global namespace. This is what's called
   a self executing anonymous function expression. 
*/
(function() {
    //keep track of how many times the user has tried to log in
    //unsuccessfully
    var loginFailures = 0;
    var usernameEle = document.getElementById("username");
    var passwordEle = document.getElementById("password");
    var errorEle = document.createElement("h3");
    errorEle.setAttribute("class", "error");
    var headerEle = document.getElementById("login-hdr");

    //html element to insert into the DOM dynamically
    errorEle.innerText = "Either or both the username and password were incorrect. Please try again.";
    //get the login button and listen for clicks on it
    document.getElementById("login-btn").addEventListener("click", function() {
	//get the username and password information from the inputs
	var username = usernameEle.innerText;
	var password = passwordEle.innerText;
	
	//validate the input fields to make sure they make sense
	//before passing them onto the server
	if(validateFields(username, password)) {
	    //make server call to check that login credentials are correct
	    if(login(username, password)) {
	      //redirect them to a new page
	    	window.location = "data_view.html";
	    }
	    //assume they aren't for now
	    else {
		//if they haven't failed once before then do this code
		//otherwise don't do anything
		if(loginFailures == 0) {
		    headerEle.appendChild(errorEle);
		}
		loginFailures++;
		clearFields();
	    }
	} //didn't pass client-side check
	else {
	    //if they haven't failed once before then do this code
	    //otherwise don't do anything besides increment the
	    //failure counter
	    if(loginFailures == 0) {
		headerEle.appendChild(errorEle);
	    }
	    loginFailures++;
	    clearFields();
	}

	/* Validating that the username and password are at least correct
	   as far as the client is concerned. */
	function validateFields(username, password) {
	    return true;
	}

	/* Server call that hopefully does something that allows me to get
	   into the system. */
	function login(username, password) {
	    return true;
	}

	/* Helper function that simply clears the text of both the username
	   and password fields */
	function clearFields() {
	    //get the value attributes and set them to null strings
	    passwordEle.value = "";
	    usernameEle.value = "";
	}
    });
})();
