/* Let's view some dummy data in an html table using Backbone, Underscore, and JQuery
in tandem. */
(function() {

	// Making the model class
	/*
	 * A constructor function is returned, which is intended to be used to
	 * instantiate new instances of the model of this type. In this case we are
	 * modeling cows.
	 */
	var Cow = Backbone.Model.extend({
		defaults : {
			birth_date : null,
			birth_weight : null,
			breed : null,
			calving_ease : null,
			chaps_id : null,
			cow_age : null,
			dam_id : null,
			elec_id : null,
			herd_id : null,
			reg_name : null,
			reg_no : null,
			sex : null,
			sex_date : null,
			sire_id : null,
			state : null
		},

		validate : function() {

		},

		initialize : function() {

		}
	});

	// Making the collection class
	/*
	 * I am telling backbone that this particular collection expects to contain
	 * within it a set of models that are of a particular type.
	 */
	var CowCollection = Backbone.Collection.extend({
		model : Cow,
		// setting a url that is the resource 'endpoint'
		url : "../jsp/cattle_info_tbl.jsp"
	});
	// Actually instantiating a new instance of the defined collection
	var cowsList = new CowCollection();

	// Make an initial fetch to the server
	cowsList.fetch().then(
			//What we should do in the case the server responded
			function() {

				/* figure out what views are in backbone */
				var DataView = Backbone.View.extend({
					// this is the DOM element that this view is attached to
					el : "#cattle",
					// this function is called once upon creation of a new view of this
					// type
					initialize : function() {
//						// listen for changes on the collection that is attached to this
//						// view
//						this.listenTo(this.collection, 'change sort', this.render);
//						this.$("#cows").table(
//								{
//									data : this.collection.toJSON().slice(
//											(this.currentPage * this.resultsPerPage)
//													- this.resultsPerPage,
//											(this.currentPage * this.resultsPerPage))
//								});
//						this.$("#table-pager").pager({
//							pages : Math.ceil(this.collection.length / this.resultsPerPage)
//						});
						
						this.render();
						//find where chaps id occurs in the array
						this.$("#cattle-table").DataTable();
						
					},
					
					//Get the template with the columns in the right order initially
					template: _.template("<table id='cattle-table'><thead><tr><%for(var i=0; i< columnNames.length;i++) {%><th><%= columnNames[i]%></th><%}%></tr></thead><tbody><%for(var i=0; i< records.length;i++) {%><tr><%for(var j=0; j< columnNames.length;j++) {%><td><%= records[i][columnNames[j]]%></td><%}%></tr><%}%></tbody></table>"),

					// A function that Backbone will invoke automatically whenever changes
					// occur.
					// Probably invoked under other conditions as well. Requires more
					// investigating.
					render : function() {
						// $el gives me a direct handle to the jquery DOM object that is
						// attached
						// to this particular view
						this.$el.html(this.template({records: this.collection.toJSON(), columnNames: ["chaps_id", "herd_id", "breed", "sex", "sex_date", "cow_age", "state"]}));
					}
				});

				// instantiate a new view here
				var cattleView = new DataView({
					collection : cowsList
				});
			});
})();